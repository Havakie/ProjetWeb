# --- Created by Ebean DDL
# To stop Ebean DDL generation, remove this comment and start using Evolutions

# --- !Ups

create table livre (
  id                            bigint auto_increment not null,
  titre                         varchar(255),
  auteur                        varchar(255),
  nb_pages                      integer not null,
  date_edition                  timestamp,
  person_id                     bigint,
  constraint pk_livre primary key (id)
);

create table person (
  id                            bigint auto_increment not null,
  firstname                     varchar(255),
  age                           integer not null,
  constraint pk_person primary key (id)
);

create index ix_livre_person_id on livre (person_id);
alter table livre add constraint fk_livre_person_id foreign key (person_id) references person (id) on delete restrict on update restrict;


# --- !Downs

alter table livre drop constraint if exists fk_livre_person_id;
drop index if exists ix_livre_person_id;

drop table if exists livre;

drop table if exists person;

